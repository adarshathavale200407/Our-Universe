OUR UNIVERSE - how to finish and publish

1. PERSONALISE  (open template.html, edit the CONFIG block at the top of the script)
   dateMet  : "YYYY-MM-DD" for the live "days since I met you" line ("" to skip)
   heart    : the 3 lines for the "Heart" star (things only you two know)
   homeLine : one optional line in the language you speak at home
2. YOUR VOICE: record the final message, save it as voice.mp3 (small, ~1 MB) next to build.py
   (it plays over the "No matter how many stars..." lines). No file = music only.
3. BUILD:      python3 build.py        (needs Pillow: pip install pillow)   -> index.html
4. PREVIEW:    in index.html replace PREVIEW_URL with your live site address
               (e.g. https://yourname.github.io/nova-7391) so WhatsApp shows the starry preview.
5. PASSCODE:   npx staticrypt index.html -p "YOUR_PASSCODE" --short -d encrypted
               Upload ONLY encrypted/index.html (renamed index.html) + preview.jpg to GitHub.
               Do NOT upload the photos/ folder or the template to the public repo.
6. PUBLISH:    new repo with an unguessable name -> Settings > Pages > Deploy from branch (main, root).
               Send her https://yourname.github.io/<repo>/ (not the github.com repo link).
7. TEST on your own phone, and by tapping the link inside WhatsApp, before sending.
