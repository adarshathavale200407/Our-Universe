"""Builds index.html (photos + optional voice note embedded) from template.html.
Usage:  python3 build.py            (put your recording at voice.mp3 first if you have one)"""
import base64, os, random
from PIL import Image, ImageDraw
d = os.path.dirname(os.path.abspath(__file__))
def uri(path, mime):
    return "data:%s;base64,%s" % (mime, base64.b64encode(open(path, "rb").read()).decode())
t = open(os.path.join(d, "template.html"), encoding="utf-8").read()
for i in range(1, 6):
    t = t.replace("{{s%d}}" % i, uri(os.path.join(d, "photos", "s%d.jpg" % i), "image/jpeg"))
v = os.path.join(d, "voice.mp3")
t = t.replace("{{voice}}", uri(v, "audio/mpeg") if os.path.exists(v) else "")
open(os.path.join(d, "index.html"), "w", encoding="utf-8").write(t)
pv = os.path.join(d, "preview.jpg")          # WhatsApp link preview: stars only, no faces
if not os.path.exists(pv):
    im = Image.new("RGB", (1200, 630), (5, 6, 15)); dr = ImageDraw.Draw(im); random.seed(7)
    for _ in range(260):
        x, y, r = random.randint(0, 1199), random.randint(0, 629), random.choice([1, 1, 2])
        dr.ellipse((x - r, y - r, x + r, y + r), fill=(207, 224, 255))
    for r, c in [(26, (60, 50, 20)), (14, (140, 110, 50)), (6, (255, 217, 138))]:
        dr.ellipse((600 - r, 315 - r, 600 + r, 315 + r), fill=c)
    im.save(pv, "JPEG", quality=85)
print("built index.html", round(os.path.getsize(os.path.join(d, "index.html")) / 1024), "KB")
